// Retrieve the current logged-in user
const getLoggedInUser = () => {
    return localStorage.getItem('loggedInUser'); // Assume "loggedInUser" stores the user ID
};

// Retrieve or initialize all user data
const getAllUserData = () => {
    const allUsers = localStorage.getItem('users');
    return allUsers ? JSON.parse(allUsers) : {};
};

// Save all user data
const saveAllUserData = (data) => {
    localStorage.setItem('users', JSON.stringify(data));
};

// Get or initialize data for the current user
const getUserData = () => {
    const allUsers = getAllUserData();
    const loggedInUser = getLoggedInUser();
    if (!loggedInUser) {
        console.error('No user is logged in!');
        return null;
    }
    if (!allUsers[loggedInUser]) {
        allUsers[loggedInUser] = { favorites: [], readBooks: [], points: 0 };
        saveAllUserData(allUsers);
    }
    return allUsers[loggedInUser];
};

// Save data for the current user
const saveUserData = (data) => {
    const allUsers = getAllUserData();
    const loggedInUser = getLoggedInUser();
    if (loggedInUser) {
        allUsers[loggedInUser] = data;
        saveAllUserData(allUsers);
    }
};

// Add a book to the user's data
const addToUserData = (key, book) => {
    const userData = getUserData();
    if (!userData) return;

    if (!userData[key].some(b => b.btitle === book.btitle)) {
        userData[key].push(book);
        if (key === 'readBooks') userData.points += book.value; // Increment points for reading
        saveUserData(userData);
    }
};
